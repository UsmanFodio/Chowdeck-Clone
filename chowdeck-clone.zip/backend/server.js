
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const axios = require('axios');
const app = express();

dotenv.config();
app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB error:', err));

const OrderSchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  items: Array,
  total: Number,
  status: { type: String, enum: ['pending', 'paid'], default: 'pending' },
  paymentRef: String
});
const Order = mongoose.model('Order', OrderSchema);

app.post('/api/checkout', async (req, res) => {
  const { userId, items, total } = req.body;
  const order = await Order.create({ userId, items, total });

  const paystackRes = await axios.post('https://api.paystack.co/transaction/initialize', {
    email: 'customer@example.com',
    amount: total * 100,
    metadata: { orderId: order._id }
  }, {
    headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET}` }
  });

  order.paymentRef = paystackRes.data.data.reference;
  await order.save();
  res.json({ paymentLink: paystackRes.data.data.authorization_url });
});

app.listen(5000, () => console.log('Server running on port 5000'));
