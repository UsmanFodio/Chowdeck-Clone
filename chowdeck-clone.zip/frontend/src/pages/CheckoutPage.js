
import React from 'react';

export default function CheckoutPage() {
  const handlePay = async () => {
    const response = await fetch('http://localhost:5000/api/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: 'demoUserId123',
        items: [{ name: 'Pizza', price: 2000 }],
        total: 2000
      })
    });
    const data = await response.json();
    window.location.href = data.paymentLink;
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Checkout</h2>
      <button onClick={handlePay} className="bg-blue-500 text-white px-4 py-2 rounded">Pay with Paystack</button>
    </div>
  );
}
